import React from "react";
import UserCrud from "./component/userForm/user-form";

function App() {
  return (
    <div>
      <UserCrud />
    </div>
  );
}

export default App;
