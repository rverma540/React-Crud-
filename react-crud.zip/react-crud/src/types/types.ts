export interface IState {
  firstName: string;
  middleName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  confirm_password: string;
  gender: string;
  bloodGroup: string;
  degree: any;
}
